package com.example.besocial.ui.login;

import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;

import android.widget.EditText;
import android.widget.Toast;

import com.example.besocial.MainActivity;
import com.example.besocial.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
    private EditText email, password;
    private Button register, login;
    private FirebaseAuth firebaseAuth;
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        email = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        register = findViewById(R.id.register);
        login = findViewById(R.id.login);
        firebaseAuth= FirebaseAuth.getInstance();

    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.register:
                Toast.makeText(this, "register", Toast.LENGTH_SHORT).show();
                break;
            case R.id.login:
                loginUser();
                break;
        }
    }

    private void loginUser() {
        String usernameString=email.getText().toString();
        String passwordString=password.getText().toString();
        if(usernameString.isEmpty())
            Toast.makeText(this, "Username field is empty", Toast.LENGTH_SHORT).show();
        else if(passwordString.isEmpty())
            Toast.makeText(this, "Password field is empty", Toast.LENGTH_SHORT).show();
        else{
            firebaseAuth.signInWithEmailAndPassword(usernameString,passwordString)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()) {
                                Intent intent = new Intent(LoginActivity.this, com.example.besocial.MainActivity.class);
                                startActivity(intent);
                                sendUserToMainActivity();
                                Toast.makeText(LoginActivity.this, "Logged in successfuly", Toast.LENGTH_SHORT).show();
                            }
                            else {
                                String errorMessage=task.getException().getMessage();
                                Toast.makeText(LoginActivity.this, "Could not log in: "+errorMessage, Toast.LENGTH_LONG).show();

                            }
                        }

                    });
        }


     //   finish();
    }

    private void sendUserToMainActivity() {
        Intent intent=new Intent(LoginActivity.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();

    }
}
